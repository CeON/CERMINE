#!/usr/bin/env python

from __future__ import division 
from segmedit.fasttrueviz import load
import sys
import os
import re

THRESHOLD = 0.8 

if len(sys.argv) != 2:
    print("Usage: remove_empty.py /path/to/xml/directory")
    exit(1)
    
path = sys.argv[1]
all_files = []

for root, _, files in os.walk(path):
    for filename in files:
        all_files.append(root + "/" + filename)

for filename in all_files:
    unknown = 0
    known = 0
    doc = load(filename)
    for page in doc:
        for zone in page:
            if zone.label.name == "unknown":
                unknown += 1
            else:
                known += 1
    if known / (known+unknown) < THRESHOLD:
        os.remove(filename)